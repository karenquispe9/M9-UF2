package com.iticbcn;

public class Main {
    public static void main(String[] args) {
        Taula taula = new Taula(5);
        taula.cridarATaula();
    }
}